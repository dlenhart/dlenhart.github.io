<?php
/*Load Content - Queries sqlite db for button click.
drewlenhart.com
11/08/2015
*/
include("database.class.php");

$db = new database();
if(!$db){
    echo $db->lastErrorMsg();
}

$sql = "SELECT * from EMPLOYEE";

$stmt = $db->query($sql);

echo "<br /><table class='table'><tr><td>NAME</td><td>AGE</td><td>ADDRESS</td><td>STATE</td><td>ZIP</td><td>PHONE</td></tr>";
while($row = $stmt->fetchArray(SQLITE3_ASSOC) ){
    echo "<tr>";
    echo "<td>". $row['NAME'] ."</td>";
    echo "<td>". $row['AGE'] ."</td>";
    echo "<td>". $row['ADDRESS'] ."</td>";
    echo "<td>". $row['STATE'] ."</td>";
    echo "<td>". $row['ZIP'] ."</td>";
    echo "<td>". $row['PHONE'] ."</td>";
    echo "</tr>";
}
echo "</table>";

$db->close();
?>