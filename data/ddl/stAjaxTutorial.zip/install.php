<?php
/*Installation Script - Creates sqlite db & creates table with mock data
drewlenhart.com
11/08/2015
*/

include("database.class.php");

$db = new database();

if(!$db){
    echo $db->lastErrorMsg();
}else {
    $stat = "Database Accessed!";
}

//Create Table
$sql = "CREATE TABLE EMPLOYEE (
    ID INT PRIMARY KEY NOT NULL,
    NAME TEXT NOT NULL, 
    AGE INT NOT NULL, 
    ADDRESS CHAR(50), 
    STATE CHAR(2),
    ZIP INT NOT NULL,
    PHONE INT NOT NULL
    )";

$createTable = $db->exec($sql);

if(!$createTable){
    $success = $db->lastErrorMsg();
} else {
    $success = "Table has been created!";
}

///Load some dummy data
$sql2 = "
INSERT INTO EMPLOYEE (ID, NAME, AGE, ADDRESS, STATE, ZIP, PHONE) 
VALUES (1, 'Bob Heyo', 32, 'California', 'CA', 90210, 2222222222 );

INSERT INTO EMPLOYEE (ID, NAME, AGE, ADDRESS, STATE, ZIP, PHONE) 
VALUES (2, 'TESTING', 32, 'Indiana', 'IN', 46789, 2222222222 );

INSERT INTO EMPLOYEE (ID, NAME, AGE, ADDRESS, STATE, ZIP, PHONE) 
VALUES (3, 'Monica M.', 99, 'Illinois', 'IL', 44322, 5555555555 );

INSERT INTO EMPLOYEE (ID, NAME, AGE, ADDRESS, STATE, ZIP, PHONE) 
VALUES (4, 'Bob Barker', 87, 'California', 'CA', 90210, 3334445432 );

INSERT INTO EMPLOYEE (ID, NAME, AGE, ADDRESS, STATE, ZIP, PHONE) 
VALUES (5, 'Tony Stark', 45, 'New York', 'NY', 676766, 44466655553 );

";

$ret = $db->exec($sql2);

if(!$ret){
    $insert = $db->lastErrorMsg();
} else {
    $insert = "Records created successfully";
}

//Close connection
$db->close();

?>
<html><head></head><body>
<h3>SQLite Install Script</h3>
<div style="border: 2px solid black; padding: 10px; background: #eeeeee">
    
<?php echo $stat; ?>
<br /><br />
<?php echo $success; ?>
<br /><br /> 
<?php echo $insert; ?>
<br /><br /> 
<a href="/">Go to Main</a>
</div>   
</body></html>