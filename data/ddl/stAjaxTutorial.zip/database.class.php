<?php 
/* Database Class - Creates Connection
drewlenhart.com
11/08/2015
*/
class database extends SQLite3{
    function __construct(){
        $this->open('example.db');
    }
}

?>