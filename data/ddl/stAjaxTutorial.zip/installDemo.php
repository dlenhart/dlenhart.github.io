<?php
/*Install Demo Code used on drewlenhart.com example - Creates sqlite db & creates table NO DATA.
drewlenhart.com
11/08/2015
*/

class database extends SQLite3{
    function __construct(){
        $this->open('testdb.db');
    }
}

$db = new database();

if(!$db){
    echo $db->lastErrorMsg();
}else {
    $stat = "Database Accessed!";
}

//Create Table
$sql = "CREATE TABLE EMPLOYEE (
    ID INT PRIMARY KEY NOT NULL,
    NAME TEXT NOT NULL, 
    AGE INT NOT NULL, 
    ADDRESS CHAR(50), 
    STATE CHAR(2),
    ZIP INT NOT NULL,
    PHONE INT NOT NULL
    )";

$createTable = $db->exec($sql);

if(!$createTable){
    $success = $db->lastErrorMsg();
} else {
    $success = "Table has been created!";
}

//Close connection
$db->close();

?>
<html><head></head><body>
<h3>SQLite Install Script</h3>
<div style="border: 2px solid black; padding: 10px; background: #eeeeee">
    
<?php echo $stat; ?>
<br /><br />
<?php echo $success; ?>
<br /><br /> 
<a href="/">Go to Main</a>
</div>   
</body></html>