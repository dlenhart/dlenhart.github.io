<!DOCTYPE html> 
<html>
<head>
<meta charset="utf-8">
<title>Ajax Demo - drewlenhart.com</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<link href="resources/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link href="resources/css/external.css" rel="stylesheet" type="text/css"/>

    
</head>
<body>
<center><h3>Ajax Demo</h3></center>
<div class="container">
        
    <div class="boxC"> 
        <button id="click1" name="click1" class="btn btn-primary">Click - using load()</button> 
        <div id="results"></div>
        <br /><br />
        <button id="click2" name="click2" class="btn btn-primary">Click - using Ajax</button> 
        <div id="resultsAjax"></div>   
    </div>
    <em>A tutorial from <a href="http://www.drewlenhart.com">www.drewlenhart.com</a>. November 2015</em>    
</div>
</body>
    
<script src="//code.jquery.com/jquery-1.11.3.min.js"></script>
<script src="resources/bootstrap/js/bootstrap.min.js"></script>
    
    <script>
    //Load external php file
    $("#click1").click(function (){
        //alert("This is a test!");   
        $("#results").load("load_div.php");
    });
        
    //load db content
    $("#click2").click(function (){ 
        $("#resultsAjax").html("Loading data........");
        loadBox();
    });
        
    function loadBox (){
        $.ajax({
            type:"GET",
            url:"load_content.php",
            data: "",
            success: function(data) {
                $("#resultsAjax").html(data);
            }
        });
    }

</script>
    
</html>