<div id="footer">
      <div class="container">
        <p class="text-muted">Powered by the ST100 Project. 2014 drewlenhart.com.</p>
      </div>
    </div>

<!-- About Modal -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title" id="myModalLabel">About ST100</h4>
      </div>
      <div class="modal-body">
           <center>
               <p><h3>ST100 version 1.0</h3><br />
                Drew D. Lenhart<br />
                (c) 2014<br />
                <a href="http://www.drewlenhart.com">www.drewlenhart.com</a><br /><br />
               </p>
          </center>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

</body>
</html>