<!DOCTYPE html> 
<html>
<head>
<meta charset="utf-8">
<title><?php get_title() ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link href="css/external.css" rel="stylesheet" type="text/css"/>
<script src="javascript/main.js" type="text/javascript"></script>
<script src="javascript/jquery-1.11.0.min.js" type="text/javascript"></script>
<script src="bootstrap/js/bootstrap.min.js"></script>
    
</head> 
<body>