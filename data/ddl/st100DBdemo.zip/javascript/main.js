/*
template - 1.01
-Drew D. Lenhart
-snowytech.com
-October 2012
-----------------------------------------------------------------------*/

/*initialize function to calculate bmi---------------------------------------------*/
function bmiE(){
	
alert("Hi");	
	
}