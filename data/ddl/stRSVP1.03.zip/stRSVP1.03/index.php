<?php
/*
	Author:  Drew D. Lenhart
	http://www.snowytech.com
	Page: index.php
	Desc: Add new rsvp requests.	
	*/
	require("dashpanel/includes/connection.php"); 
	include ("dashpanel/includes/libClean.php");
	
	if ($_SERVER["REQUEST_METHOD"] == "POST") {
		if (empty($_POST["first"])) {
			$firstErr = "Missing *** Must have a first name!";
		}
		else if (empty($_POST["last"])) {
			$lastErr = "Missing *** Must have a last name!";
		}
		else {
        $first_name = sqlClean($_POST['first']);
		$last_name = sqlClean($_POST['last']);
		$attend = sqlClean($_POST['attend']);
		$num = sqlClean($_POST['number']);
		$num2 = sqlClean($_POST['child']);
		
		if(isset($_POST['go']))
			{
			//Insert data to db
			$statement = $conn->prepare('INSERT INTO guests (firstname, lastname, attend, number, numberCH) VALUES (:var1,:var2,:var3,:var4,:var5)');

			$statement->bindParam(':var1',$first_name);
			$statement->bindParam(':var2',$last_name);
			$statement->bindParam(':var3',$attend);
			$statement->bindParam(':var4',$num);
			$statement->bindParam(':var5',$num2);
			$statement->execute();

			//Posts message when data is sent
			$added = "<center><h1>Thank you for Accepting/Declining the RSVP!</h1><br /><br /></center>";
			
			//Gets the email set by user from the settings page
				$email = $conn->query("SELECT * FROM email where id = '100'");
				if (!$email) {
					die("Database query failed: ERR NOemailQuer");
				}
				// Set fetching mode for email
				$email->setFetchMode(PDO::FETCH_ASSOC);				
				$dsp_email  = $email -> fetch();

			//Gets the send email address (from)
				$send_email = $conn->query("SELECT * FROM email where id = '200'");
				if (!$send_email) {
					die("Database query failed: ERR NOemailQuer");
				}
				// Set fetching mode for from email
				$send_email->setFetchMode(PDO::FETCH_ASSOC);				
				$dsp_semail  = $send_email -> fetch();
				
			//Gets the option if sending email.
				$send_check = $conn->query("SELECT * FROM email where id = '100'");
				if (!$send_check) {
					die("Database query failed: ERR NOemailQuer");
				}
				// Set fetching mode for send check
				$send_check->setFetchMode(PDO::FETCH_ASSOC);				
				$dsp_check  = $send_check -> fetch();
				
				//variable that checks if there is yes or no.
				$check_stat = $dsp_check['confirm'];
				
				$to = $dsp_email['send_mail'];
				$from = $dsp_semail['send_mail'];
				$subject = "You have a new Reservation for the wedding!";
				$subject2 = "A reservation has been declined!";
	
				//Checks if yes is set in settings, if yes execute mail send
				if($check_stat == "yes"){
					if ($attend == "yes"){
						$output = "";
						$output .= $first_name;
						$output .= " ";
						$output .= $last_name;
						$output .= "\n";
						$output .= "Adults attending: ";
						$output .= $num;
						$output .= "\n";
						$output .= "Children attending: ";
						$output .= $num2;
						mail($to, $subject, $output, "From:" . $from);
					}else{
						$output = "";
						$output .= $first_name;
						$output .= " ";
						$output .= $last_name;	
						$output .= "\n";
						$output .= "Has decided not to attend the event.";
						mail($to, $subject2, $output, "From:" . $from);
					}
				}
    		}
	}
}
	
?>

<!DOCTYPE html> 
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width">
<title>stRSVP - by snowytech</title>
<link href="dashpanel/css/external.css" rel="stylesheet" type="text/css"/>
<link href="dashpanel/css/jquery.mobile-1.3.1.min.css" rel="stylesheet" type="text/css"/>
<link href="dashpanel/css/snowyT2.css" rel="stylesheet" type="text/css"/>

<script src="dashpanel/javascript/jquery-1.8.2.min.js" type="text/javascript"></script>
<script src="dashpanel/javascript/jquery.mobile-1.3.1.min.js" type="text/javascript"></script>

</head> 
<body>

<div data-role="page" id="page" class = "mainPage" data-theme="a">
					
   <div data-role="content">
		<center><h1>RSVP:</h1></center>
        <b><?php echo $added;?></b>

		Thank you for making a reservation to our event.  Please be sure to fill in all fields.<br /><br />
	  
		<form method="post" id="add_form" action="#">

		<label for="first"><b>First Name: <b><?php echo $firstErr;?></b></b></label>
		<input type="text" name="first" id="first" data-theme="a" />
		
		
		<label for="last"><b>Last Name: <b><?php echo $lastErr;?></b></b></label>
		<input type="text" name="last" id="last" data-theme="a" />
		
		<br />
		<label for="attend"><b>Attending (yes/no):</b></label>
		<select name="attend" id="attend" class="group" data-theme="a" data-native-menu="false" data-mini="true" data-inline="true">
				<option value="yes">yes</option>
				<option value="no">no</option>
		</select>

		<br />
		<label for="number"><b>Number of Adults(please count yourself):</b></label>
		<select name="number" id="number" class="group" data-theme="a" data-native-menu="false" data-mini="true" data-inline="true">
				
				<option value="1">1</option>
				<option value="2">2</option>
				<option value="3">3</option>
				<option value="4">4</option>
				<option value="5">5</option>
				<option value="6">6</option>
				<option value="7">7</option>
				<option value="8">8</option>
		</select>

		<br />

		<label for="child"><b>Number of Children:</b></label>
		<select name="child" id="child" class="group" data-theme="a" data-native-menu="false" data-mini="true" data-inline="true">
				<option value="0">0</option>
				<option value="1">1</option>
				<option value="2">2</option>
				<option value="3">3</option>
				<option value="4">4</option>
				<option value="5">5</option>
				<option value="6">6</option>
				<option value="7">7</option>
				<option value="8">8</option>
		</select>
		<center>
		<input name="go" id ="go" type="submit" value="Send" onClick=""data-theme="e" data-inline="true">
		<input type="reset" id="cancel" name="reset" value="Reset" data-theme="a" data-inline="true">
		</center>
	</form>
	<br />
	  <center>powered by:<br /><a href="http://www.snowytech.com"><img src="dashpanel/images/snowylogosmall.png" width="180" height="36"></a></center>
	<br /><br />
   </div>

</div>

<?php $conn = null; ?>
</body>
</html>
