<?php 
/*
	Author:  Drew D. Lenhart
	http://www.snowytech.com
	Page: setup.php
	Desc: stRSVP Installer script
	*/
	
	require("dashpanel/includes/connection.php");
?>

<!DOCTYPE html> 
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width">
<title>stRSVP Installer 1.00</title>
<link href="dashpanel/css/external.css" rel="stylesheet" type="text/css"/>
<link href="dashpanel/css/jquery.mobile-1.3.1.min.css" rel="stylesheet" type="text/css"/>
<link href="dashpanel/css/snowyT2.css" rel="stylesheet" type="text/css"/>

<script src="dashpanel/javascript/jquery-1.8.2.min.js" type="text/javascript"></script>
<script src="dashpanel/javascript/jquery.mobile-1.3.1.min.js" type="text/javascript"></script>

</head> 
<body>
<div data-role="page" id="main" data-theme="a" data-dismissible="false" data-overlay-theme="a">
	<div data-role="header" data-theme="a">
		<h1>stRSVP Installer</h1>
		
		</div>
		
		<div data-role="content" style="margin-left:20%; margin-right:20%">
	<?php echo $top_button;?>	
<h1>Setup Instructions</h1> 

Thank you for choosing stRSVP!  Follow the instructions below to get up and running.  This setup script will create all necessary tables and a user login upon completion.<br /><br /><br /><br />

<b>Requirements:</b><br />
<center><b>PHP 5.2+<br />
	MySQL 5+<br />
	PHP mail Function enabled
	</b></center>

<br /><br /><br />
<b>Step 1:</b><br />Through your hosting provider, create a new "database" with a username and login.  If using cPanel, use the provided mySQL Database wizard, this will create your database name, username, and password.  Please be sure to give the username "ALL" privileges.  Please don't mistake this username and password created for your database with the username and password that will be created in step 4!!'<br /><br /><br />
<center>
	<img src="dashpanel/images/msqldbw.png" width="132" height="73"></a>
</center>

<br /><br />
<b>Step 2:</b><br />Edit <b>/dashpanel/includes/connection.php</b>.  <br /><br />Edit lines 11,12,13.  Add the database, username, and password with what you created in step 1.  At this point you will not need to do anything with this username and password.<br /><br /><br />

<center>
	<img src="dashpanel/images/dbinfo.png" width="608" height="224"></a>
</center>

<br /><br />

<b>Step 3:</b><br />Click the button below to build tables.<br /><br />

<form action="" method="post"> 
    <input type="submit" name="submit" value="Build Tables" /> 
</form>
<?php 
//stRSVP Installer v1.0 - Remember to delete this from your webserver when complete!
    
	if(isset($_POST['submit']))
	{
		$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$conn->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);

		$q="DROP TABLE IF EXISTS `guests`;
			DROP TABLE IF EXISTS `email`;
			DROP TABLE IF EXISTS `profile`;
			DROP TABLE IF EXISTS `title`;";
		$conn->exec($q); 

		//Create Tables
		$sql = "CREATE TABLE guests (
			id int(8) NOT NULL AUTO_INCREMENT,
			firstname varchar(25) NOT NULL,
			lastname varchar(40) NOT NULL,
			attend varchar(4) NOT NULL,
			number int(3) NOT NULL,
			numberCH int(4) NOT NULL,
			postdate timestamp DEFAULT CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
			PRIMARY KEY (id));

		CREATE TABLE email (
	        id int(3) NOT NULL,
	        send_mail varchar(35) NOT NULL,
	        confirm varchar(3) NOT NULL,
			PRIMARY KEY (id));

		CREATE TABLE profile (
	        User_ID varchar(20) NOT NULL,
	        u_pass varchar(255) NOT NULL,
	        salt char(16) NOT NULL);

		CREATE TABLE title (
	        id int(3) NOT NULL,
	        title varchar(100) NOT NULL
	        )";

		//Execute query
		try {
		 $result = $conn->exec($sql);
			if(!$result){
				$success = "<center><h3>Tables created! Proceed to next step!</h3></center>";
				$success_check = true;
			}
		 } catch (PDOException $e) {
		 $e->getMessage();
		 $success_check = false;
		 $success = "<center><h3>There was an issue creating DB, please double check the requirements.</h3></center>";
		}
		//test data
		$statement = $conn->prepare('INSERT INTO guests (firstname, lastname, attend, number, numberCH) VALUES ("Bob","Test User","yes","2","4")');

		$statement->execute();

		//test data for settings
		$settings = $conn->prepare('INSERT INTO title (id, title) VALUES ("100","Default Title")');

		$settings->execute();

		//test data for email
		$email = $conn->prepare('INSERT INTO email (id, send_mail, confirm) VALUES ("100","your@email.com","no")');

		$email->execute();

		//test data for send email
		$s_email = $conn->prepare('INSERT INTO email (id, send_mail, confirm) VALUES ("200","your@email.com","0")');

		$s_email->execute();

	}
$conn = null;
?>

<?php echo $success; ?>
<br /><br />
<?php 
if($success_check == true){
	$show_button = "<b>Step 4:</b>  Now we are ready to create the login for the Dashpanel.<br /><br /><a href='user_setup_script.php' data-role='button' data-theme='a'>Next Step</a>";
	$top_button = "<a href='user_setup_script.php' data-role='button' data-theme='a'>Next Step: Create User</a>";
}else{
	$show_button = "";
}

echo $show_button;
?>
<br /><br />

<center>stRSVP Installer 1.00<br />
	<a href="http://www.snowytech.com" target="_blank"><img src="dashpanel/images/snowylogosmall.png" width="180" height="36"></a>
</center>
	</div>
	
</div>


</body>
</html>