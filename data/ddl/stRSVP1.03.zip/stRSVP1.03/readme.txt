stRSVP 1.03 - February 2014
snowytech
http://www.snowytech.com

README

Installation
----------------

1. Extract files from zip file.  Create a new directory on web host and upload all files.

2. Create Database with username and password.  This can be done with tools provided by your hosting provider.  If you have cPanel, for example, use the MySQL Database Wizard.  This is the easiest method to setting up a database.  Write down your database name, username, and password.

2. Edit lines, 11, 12, 13 in “dashpanel/includes/connection.php” and within the variable quotes, enter your database, username and password.  

3. Point browser to "setup.php" in root of the newly created directory and follow instructions.

4. When complete, DELETE "setup.php" and "user_setup_script.php".

5. Keep "user_setup_script.php" stored on personal computer.  This file can be re-uploaded at a later time if an extra login needs to be created.



How To Use:
----------------

1. Give users the url to the "index.php" in root.  This page is where users RSVP.  

2. "index.php" is the default user RSVP page.  This page uses jquerymobile and uses a very bland jquerymobile theme.  If you are comfortable with jquerymobile, you can visit jquerymobile.com and create a new "theme" using Themeroller.  Create your new theme, and place in:

dashpanel/css/

Don't forget to add your new jquerymobile CSS theme in the header of "index.php".  stRSVP uses a css file called "dashpanel/css/snowyT2.css".  Replace "snowyT2.css" with the name of your new theme.

3. A non-jquerymobile template is also provided, "index_template.php".  You can custom tailor this page to your needs without using jquerymobile.  Backup the old "index.php" and rename the template file to "index.php".

5. Start using!  Navigate to the Settings page and fill in the "send to" email address (your email), this is the email where you will receive notifications that an rsvp has been made.  Also set the "send from" email address.  It's recommended you either put your own email address, or a made up address that matches your domain, such as "reservations@yourdomain.com".

6. Test by entering RSVP entries.  Make sure email notifications come through. *HINT - if email notifications don't appear to be flowing, check your junk/spam folder.

Common Errors:
----------------

1. When I click the “Create Tables” in the setup script I receive a funky error at the bottom of the page.

Answer:  This is due to the /includes/connection.php file having incorrect credentials.  Verify the DATABASE, USERNAME and PASSWORD that were created are correct.

Sometimes when setting up database, username, and password in cPanel, it adds your cPanel login before the database and username, for example:

Database:
cPanellogin_databasename

Username:
cPanellogin_username

By visiting the MySQL Database section in cPanel, you can verify information.

----------------

thanks for downloading!