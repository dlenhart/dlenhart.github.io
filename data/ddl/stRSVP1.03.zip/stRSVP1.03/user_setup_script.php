<?php 
//Simple setup script to create initial user...... DELETE THIS WHEN DONE!!
    require("dashpanel/includes/connection.php");

    if(!empty($_POST)) 
    { 
      	//Create new User.
		if(empty($_POST['username'])) 
        { 
            $err_usr = "Please enter a username!";
        } 
		else if(empty($_POST['password'])) 
        { 
            $err_pass = "Please enter a password!";
        }else{
			$query = " 
	            SELECT 
	                1 
	            FROM profile 
	            WHERE 
	                User_ID = :username 
	        "; 

	        $query_params = array( 
	            ':username' => $_POST['username'] 
	        ); 

	        try 
	        { 
	            $stmt = $conn->prepare($query); 
	            $result = $stmt->execute($query_params); 
	        } 
	        catch(PDOException $ex) 
	        { 
	            die("Failed to run query: " . $ex->getMessage()); 
	        } 

	        $row = $stmt->fetch(); 
	        if($row) 
	        { 
	            $err_usr = "This username already exists!";
	        }else{
				$query = " 
		            INSERT INTO profile ( 
		                User_ID, 
		                u_pass, 
		                salt
		            ) VALUES ( 
		                :username, 
		                :password, 
		                :salt
		            ) 
		        "; 

		        $salt = dechex(mt_rand(0, 2147483647)) . dechex(mt_rand(0, 2147483647)); 

		        $password = hash('sha256', $_POST['password'] . $salt); 

		        for($round = 0; $round < 65536; $round++) 
		        { 
		            $password = hash('sha256', $password . $salt); 
		        } 

		        $query_params = array( 
		            ':username' => $_POST['username'], 
		            ':password' => $password, 
		            ':salt' => $salt
		        ); 

		        try 
		        { 
		            $stmt = $conn->prepare($query); 
		            $result = $stmt->execute($query_params); 
		        } 
		        catch(PDOException $ex) 
		        { 
		            die("Failed to run query: " . $ex->getMessage()); 
		        } 

		        $success = "<center><h1>You have successfully created your first user!</h1></center>";
			} 
	        
		} 
	
    } 
     
?> 
<!DOCTYPE html> 
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width">
<title>stRSVP - User Setup</title>
<link href="dashpanel/css/external.css" rel="stylesheet" type="text/css"/>
<link href="dashpanel/css/jquery.mobile-1.3.1.min.css" rel="stylesheet" type="text/css"/>
<link href="dashpanel/css/snowyT2.css" rel="stylesheet" type="text/css"/>

<script src="dashpanel/javascript/jquery-1.8.2.min.js" type="text/javascript"></script>
<script src="dashpanel/javascript/jquery.mobile-1.3.1.min.js" type="text/javascript"></script>

</head> 
<body>
<div data-role="page" id="about" data-theme="a" data-dismissible="false" data-overlay-theme="a">
	<div data-role="header" data-theme="a">
		<h1>stRSVP Installer</h1>
		
		</div>
		
		<div data-role="content" style="margin-left:20%; margin-right:20%">
		
<h1>Create Initial User</h1> 


<form action="user_setup_script.php" method="post"> 
    Username: <b><?php echo $err_usr; ?></b><br /> 
    <input type="text" name="username" value="" /> 
    Password: <b><?php echo $err_pass; ?></b><br /> 
    <input type="password" name="password" value="" /> 
    <br /><br /> 
    <input type="submit" value="Create User" /> 
</form>
<?php echo $success; ?>
<br /><br />

You are now ready to start using stRSVP!  Here are a couple tips:<br />
<ol>
	<li>Give users the address to index.php in your root directory, this is where users will make the rsvp.</li><br />
	<li>The Dashpanel is located /dashpanel/index.php.  This is the login page to the Dashpanel.</li><br />
	<li>You can use this script <b>"user_setup_script.php"</b> if you need to create additional users or if you forgot your password.</li><br />
	<li>DO NOT RUN the <b>"setup.php"</b> script after users have started making RSVP's!  The setup script will delete everything in your database and you will loose ALL data!  Delete this script immediately after setting up script!</li>
</ol>
<br /><br />
<b>Final Step:</b> Make sure you delete the setup files!  Remove <b>"setup.php" and "user_setup_script.php"</b>.  If you do not delete these files you risk some one wiping out your database and gaining access to your Dashpanel!  However, if you need additional users, I would keep the <b>"user_setup_script.php"</b> handy on your home computer if you need it.  Simply re-upload to the root directory when needed, but please remove from your website after complete.<br /><br /><center>Please visit snowytech.com and use the contact page for support!</center>
<br /><br />
<a href='dashpanel/index.php' data-role='button' data-theme='a'>Proceed to login</a>
<br /><br /><br />
<center>stRSVP Installer 1.00<br />
	<a href="http://www.snowytech.com" target="_blank"><img src="dashpanel/images/snowylogosmall.png" width="180" height="36"></a>
</center>
	</div>
	
</div>

</body>
</html>