<?php 
/*
	Author:  Drew D. Lenhart
	http://www.snowytech.com
	Page: dashpanel/edit_entry.php
	Desc: Edit a rsvp.	
	*/
	session_start(); 
	$auth= $_SESSION['auth'];
	if ( $auth != "yes" )
	{
		header("Location: index.php");
		exit();
	}

include("includes/header.php"); ?>

<!--Edit View----------------------------------------------------- -->
<div data-role="page" id="view" data-theme="a">
	<div data-role="header" data-theme="a">
		<h1>Edit Entry</h1>
		<div data-role="navbar" data-iconpos="bottom">
			<ul>
				<li><a href="dash.php" data-role="button" data-inline="true" data-icon="check">Attending</a></li>
				<li><a href="noattend.php" data-role="button" data-inline="true" data-icon="minus">Not Attending</a>	</li>
				<li><a href="complete.php" data-role="button" data-inline="true" data-icon="bars">Print List</a></li>
				<li><a href="settings.php" data-role="button" data-inline="true" data-icon="gear">Settings</a></li>
			</ul>
		</div>
		<a href="about.php" data-rel="" data-icon="bars" data-iconpos="" class="ui-btn-left">About</a>
		<a href="logout.php" data-rel="" data-icon="bars" data-iconpos="" class="ui-btn-right">Log Out</a>
	</div>
		<div data-role="content" style="margin-left: 15%; margin-right: 15%">
		<?php
				require("includes/connection.php");
				$entryID = strip_tags($_GET['ID']);
				
				$sth = $conn->query("SELECT * FROM guests where id = '$entryID'");
				if (!$sth) {
					die("Database query failed: ERR NOeditQueryNO");
				}
				// Set fetching mode
				$sth->setFetchMode(PDO::FETCH_ASSOC);				
				$row  = $sth -> fetch();
				
				$id = $row['id'];
				$first = $row['firstname'];
				$last = $row["lastname"];
				$num = $row["number"];
				$num2 = $row["numberCH"];
				$date = $row['postdate'];
				$dateConverted = date('F d, Y  h:i:s A', strtotime($date));
				
		?>
		<h2><? echo $content; ?></h2>
		<b>Posted on:</b><br /> <? echo $dateConverted; ?>
		<br />
		<hr />
				
		<!--Edit portion -->
		<form name="form1" method="post" action="">
		 
		<?//echo $row['id'];?>
		<input name ="id" type="hidden" id="id" value="<?echo $id;?>">
		
		<label for="firstname"><b>First Name:</b></label>
		<input type="text" name="firstname" id="firstname" data-theme="a" value="<?echo $first;?>" />
		
		<label for="lastname"><b>Last Name:</b></label>
		<input type="text" name="lastname" id="lastname" data-theme="a" value="<?echo $last;?>" />

		<label for="attend"><b>Attending?:</b></label>
			<?php
			//Pulls data and puts into a select box.(for attending)
			$sql_select = $conn->query("SELECT * FROM guests where id = '$entryID'");
			if (!$sql_select) {
				die("Database query failed: ERR NOattendingQuery");
			}
			
			echo "<select name='attend' id='attend' class='group' data-theme'a' data-native-menu='false' data-mini='true' data-inline='true'>"; 
			while($row2 = $sql_select->fetch(PDO::FETCH_ASSOC)) 
			{        
				echo "<option value='" . $row2['attend'] . "'>" . $row2['attend'] . "</option>"; 
			}
			echo "<option value='yes'>yes</option>";
			echo "<option value='no'>no</option>";
			echo "</select>";
			?>
			
			
		<label for='number'><b>Adults Attending?:</b></label>
			<?php
			//Pulls data for number of adults
			$sql_select2 = $conn->query("SELECT * FROM guests where id = '$entryID'");
			if (!$sql_select2) {
				die("Database query failed: ERR NOattendingNUMQuery");
			}
			echo "<select name='number' id='number' class='group' data-theme'a' data-native-menu='false' data-mini='true' data-inline='true'>"; 
			while($row3 = $sql_select2->fetch(PDO::FETCH_ASSOC)) 
			{        
				echo "<option value='" . $row3['number'] . "'>" . $row3['number'] . "</option>"; 
			}
			echo "<option value='0'>0</option>";
			echo "<option value='1'>1</option>";
			echo "<option value='2'>2</option>";
			echo "<option value='3'>3</option>";
			echo "<option value='4'>4</option>";
			echo "<option value='5'>5</option>";
			echo "<option value='6'>6</option>";
			echo "<option value='7'>7</option>";
			echo "<option value='8'>8</option>";
			echo "</select>";
			?>
			
		<label for='numberCH'><b>Children Attending?:</b>
			<?php 
			//Pulls data for number of children
			$sql_select3 = $conn->query("SELECT * FROM guests where id = '$entryID'");
			if (!$sql_select3) {
				die("Database query failed: ERR NOattendingCHILDQuery");
			}
			
			echo "<select name='numberCH' id='numberCH' class='group' data-theme'a' data-native-menu='false' data-mini='true' data-inline='true'>"; 
			while($row4 = $sql_select3->fetch(PDO::FETCH_ASSOC)) 
			{        
				echo "<option value='".$row4['numberCH']."'>".$row4['numberCH']."</option>"; 
			}
			echo "<option value='0'>0</option>";
			echo "<option value='1'>1</option>";
			echo "<option value='2'>2</option>";
			echo "<option value='3'>3</option>";
			echo "<option value='4'>4</option>";
			echo "<option value='5'>5</option>";
			echo "<option value='6'>6</option>";
			echo "<option value='7'>7</option>";
			echo "<option value='8'>8</option>";
			echo "</select>";
			?>
			
		<input name="submit" type="submit" value="Submit" onClick="return confirm('Are you sure you want to add to this record?')" data-theme="e">
		
		
		<?php 
		if(isset($_POST['submit']))
		{
			$del_id = $_POST['id'];
			$first_id = $_POST['firstname'];
			$last_id = $_POST['lastname'];
			$attending = $_POST['attend'];
			$number = $_POST['number'];
			$numberCH = $_POST['numberCH'];
			
			$sql="UPDATE guests SET firstname='$first_id', lastname='$last_id', attend='$attending', number='$number', numberCH='$numberCH' WHERE id='$del_id'";
			$result=$conn->exec($sql);
	
			if($result){echo "<meta http-equiv=\"refresh\" content=\"0;URL=dash.php\">";}
			mysql_close();
		}
		?>	

		</form>
		
		<a href="dash.php" data-role="button" data-theme="a">Cancel</a>		
	</div>
	
	
</div>

<?php include("includes/footer.php"); ?>