<!DOCTYPE html> 
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width">
<title>stRSVP - snowytech</title>
<link href="css/external.css" rel="stylesheet" type="text/css"/>
<link href="css/jquery.mobile-1.3.1.min.css" rel="stylesheet" type="text/css"/>
<link href="css/snowyT2.css" rel="stylesheet" type="text/css"/>

<script src="javascript/jquery-1.8.2.min.js" type="text/javascript"></script>
<script src="javascript/jquery.mobile-1.3.1.min.js" type="text/javascript"></script>

<script src="javascript/main.js" type="text/javascript"></script>
</head> 
<body>

