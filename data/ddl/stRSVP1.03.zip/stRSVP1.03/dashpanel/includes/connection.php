<?php
/*
	Author:  Drew D. Lenhart
	http://www.snowytech.com
	Page: connection.php
	Desc: Get connected to DB.	
	*/
//Connect to DB using PDO.

//Update the variables below with your username, password, and database name.
$username = "";
$password = "";
$database = "";

try {
    $dbh = new PDO("mysql:host=localhost;dbname=$database", $username, $password);
    $conn = $dbh;
}
catch( PDOException $exception  ) {
    echo "Connection error :" . $exception ->getMessage();
}
?>
