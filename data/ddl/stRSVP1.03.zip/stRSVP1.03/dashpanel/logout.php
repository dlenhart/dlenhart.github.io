<?php 
/*
	Author:  Drew D. Lenhart
	http://www.snowytech.com
	Page: dashpanel/logout.php
	Desc: Logout script.	
	*/
	session_start(); 
 
session_destroy();
header("Location: index.php");

?>
