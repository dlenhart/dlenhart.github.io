<?php 
/*
	Author:  Drew D. Lenhart
	http://www.snowytech.com
	Page: dashpanel/full_view.php
	Desc: View single entries.	
	*/
	session_start(); 
	$auth= $_SESSION['auth'];
	if ( $auth != "yes" )
	{
		header("Location: index.php");
		exit();
	}
include("includes/header.php"); 
?>

<!--Full View----------------------------------------------------- -->
<div data-role="page" id="view" data-theme="a">
	<div data-role="header" data-theme="a">
		<h1>Full Entry Attending</h1>
	</div>
		
		<div data-role="content">
		<?php
				require("includes/connection.php");
				$entryID = strip_tags($_GET['ID']);
				$sth = $conn->query("SELECT * FROM guests where id = '$entryID'");
					if (!$sth) {
						die("Database query failed: ERR NOfullVIEW");
					}
				// Set fetching mode
				$sth->setFetchMode(PDO::FETCH_ASSOC);
				
				$row  = $sth -> fetch();
				
				$first = $row['firstname'];
				$last = $row["lastname"];
				$num = $row["number"];
				$num2 = $row["numberCH"];
				$date = $row['postdate'];
				$dateConverted = date('F d, Y  h:i:s A', strtotime($date));
		?>
		<h2><? echo $first; ?><?echo " ";?><? echo $last; ?></h2>
		Made reservation on: <? echo $dateConverted; ?><br /><br />
		Adults in party:  <? echo $num; ?><br />
		Children in party:  <? echo $num2; ?><br /><br />
				<a href="edit_entry.php?ID=<? echo $entryID ?>" data-rel="" data-role="button" data-theme="e">Edit</a>	

		<form name="form1" method="post" action="">
		<input name="delete" type="submit" id="delete" value="Delete" onClick="return confirm('Are you sure you want to delete this record? Your entry will be permanently removed from the database!')" data-theme="e">
		<?php

			if(isset($_POST['delete'])){
			$sql = "DELETE FROM guests WHERE id='$entryID'";
			$result=$conn->exec($sql);
			
			if($result){
				echo "<meta http-equiv=\"refresh\" content=\"0;URL=delete_success.php\">";
			}
		mysql_close();
			}
		?>

		</form>
	
		<a href="dash.php" data-rel="" data-role="button" data-theme="a">Back</a>		
	</div>
	
</div>

<?php include("includes/footer.php"); ?>
