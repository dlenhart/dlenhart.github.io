<?php 
/*
	Author:  Drew D. Lenhart
	http://www.snowytech.com
	Page: dashpanel/settings.php
	Desc: Change settings page.	
	*/
	session_start(); 
	$auth= $_SESSION['auth'];
	if ( $auth != "yes" )
	{
		header("Location: index.php");
		exit();
	}
include("includes/header.php"); 
require("includes/connection.php");	
include ("includes/libClean.php");
?>
<div data-role="page" id="page" class = "mainPage" data-theme="a">
	<div data-role="header" data-theme="a">
		<h1>RSVP Dashpanel</h1>
		<div data-role="navbar" data-iconpos="bottom">
			<ul>
				<li><a href="dash.php" data-role="button" data-inline="true" data-icon="check">Attending</a></li>
				<li><a href="noattend.php" data-role="button" data-inline="true" data-icon="minus">Not Attending</a>	</li>
				<li><a href="complete.php" data-role="button" data-inline="true" data-icon="bars">Print List</a></li>
				<li><a href="settings.php" data-role="button" data-inline="true" data-icon="gear">Settings</a></li>
			</ul>
		</div>
		<a href="about.php" data-rel="" data-icon="bars" data-iconpos="" class="ui-btn-left">About</a>
		<a href="logout.php" data-rel="" data-icon="bars" data-iconpos="" class="ui-btn-right">Log Out</a>
	</div>		
   <div data-role="content"  style="margin-left:15%; margin-right:15%">
		<center><h1>Settings</h1></center>
		<?php
		//Detects if setup files are on system
		if(file_exists('../setup.php')){
			echo "<div style='background:yellow;margin: 2px 2px 2px 2px;'>*Warning:<br />It has been detected that you still have the setup files on your webroot, please manually delete: <br /><br /><b>setup.php</b></div><br />";
		}
		if(file_exists('../user_setup_script.php')){
			echo "<div style='background:yellow;margin: 2px 2px 2px 2px;'>*Warning:<br />It has been detected that you still have the setup files on your webroot, please manually delete: <br /><br /><b>user_setup_script.php</b></div><br />";
		}
		
		?>
	  Set the title of your RSVP. (eg.  Spencer/Lenhart Wedding)  <br />
	  **Used for the title of the print list.<br /><br />

			<?php
				//query to get title
				$sth = $conn->query("SELECT * FROM title where id = '100'");
				if (!$sth) {
					die("Database query failed: ERR NOtitleQueryNO");
				}
				// Set fetching mode for title
				$sth->setFetchMode(PDO::FETCH_ASSOC);				
				$row  = $sth -> fetch();
				
				//query to get send email.
				$email = $conn->query("SELECT * FROM email where id = '100'");
				if (!$email) {
					die("Database query failed: ERR NOsendEMAILueryNO");
				}
				// Set fetching mode for send email
				$email->setFetchMode(PDO::FETCH_ASSOC);				
				$dsp_email  = $email -> fetch();
				
				//query to get send from email
				$send_email = $conn->query("SELECT * FROM email where id = '200'");
				if (!$send_email) {
					die("Database query failed: ERR NOsendFROMQueryNO");
				}
				// Set fetching mode for title
				$send_email->setFetchMode(PDO::FETCH_ASSOC);				
				$dsp_semail  = $send_email -> fetch();
				
				//Output variables
				$title = $row['title'];
				$show_email = $dsp_email['send_mail'];
				$show_send_email = $dsp_semail['send_mail'];
			?>

		<!--Edit portion -->
		<form name="form1" method="post" action="">
		 
		<label for="title"><b>Title: </b></label>
		<input type="text" name="title" id="title" data-theme="a" value="<?echo $title;?>" />
		<br />
		<input name="submit" type="submit" value="Update Title" data-inline="true" onClick="return confirm('Are you sure you want to add to this record?')" data-theme="e"></form>
		<hr><br />
				<?php 
		if(isset($_POST['submit']))
		{
			$new_title = sqlClean($_POST['title']);
	
			$sql="UPDATE title SET title='$new_title' WHERE id='100'";
			$result=$conn->exec($sql);
	
			if($result){echo "<meta http-equiv=\"refresh\" content=\"0;URL=settings.php\">";}
			
		}
		?>	

		<b>Set email address:</b><br />
		**You must set this email address to an email account you want to receive emails when there is a new reservation.
		<br />
		<form name="form2" method="post">
		<label for="notify"><b>Check yes or no if you want to receive email notifications:</b></label>
		
			<?
			//Pulls data and puts into a select box.
			$sql_select = $conn->query("SELECT * FROM email where id = '100'");
			if (!$sql_select) {
				die("Database query failed: ERR NOattendingQuery");
			}
	
			echo "<select name='notify' id='notify' class='group' data-theme'a' data-native-menu='false' data-mini='true' data-inline='true'>"; 
			while($row_get = $sql_select->fetch(PDO::FETCH_ASSOC)) 
			{        
				echo "<option value='" . $row_get['confirm'] . "'>" . $row_get['confirm'] . "</option>"; 
			}
			echo "<option value='yes'>yes</option>";
			echo "<option value='no'>no</option>";
			echo "</select>";
			?>

		<input type="text" name="email" id="email" data-theme="a" value="<?echo $show_email;?>" />
		<input name="submit2" type="submit" value="Update Email" data-inline="true" onClick="return confirm('Are you sure you want to add to this record?')" data-theme="e">
		</form><hr> <br />
  					<?php 
		if(isset($_POST['submit2']))
		{
			$new_email = sqlClean($_POST['email']);
			$notify = $_POST['notify'];
			$sql="UPDATE email SET send_mail ='$new_email', confirm = '$notify' WHERE id='100'";
			$result=$conn->exec($sql);
	
			if($result){echo "<meta http-equiv=\"refresh\" content=\"0;URL=settings.php\">";}
			
		}
		?>	

		<b>Set SEND email address:</b><br />
		**You must set this email address, this is the email address that SENDS out the rsvp notifications.
		<br />
		<form name="form3" method="post">
		
		<input type="text" name="email2" id="email2" data-theme="a" value="<?echo $show_send_email;?>" />
		<input name="submit3" type="submit" value="Update Send Email" data-inline="true" onClick="return confirm('Are you sure you want to add to this record?')" data-theme="e">
		</form>
  					<?php 
		if(isset($_POST['submit3']))
		{
			$new_send_email = sqlClean($_POST['email2']);
	
			$sql="UPDATE email SET send_mail ='$new_send_email' WHERE id='200'";
			$result=$conn->exec($sql);
	
			if($result){echo "<meta http-equiv=\"refresh\" content=\"0;URL=settings.php\">";}
			
		}
		?>	
   </div>

</div>

<?php include("includes/footer.php"); ?>