<?php 
/*
	Author:  Drew D. Lenhart
	http://www.snowytech.com
	Page: dashpanel/guest_count.php
	Desc: counts number of guests for totals on dash page.	
	*/
	session_start(); 
	$auth= $_SESSION['auth'];
	if ( $auth != "yes" )
	{
		header("Location: index.php");
		exit();
	}

require("includes/connection.php");
//query to get attending
$count = $conn->query("SELECT SUM(number) FROM guests WHERE attend='yes'");
	if (!$count) {
		die("Database query failed: ERR NOsumQuery");
	}
//query to get children attending
$count_child = $conn->query("SELECT SUM(numberCH) FROM guests WHERE attend='yes'");
	if (!$count_child) {
		die("Database query failed: ERR NOchildQuery");
	}

echo "Total adults attending: ";						
while($new_count = $count->fetchColumn()){
		$adult_count = $new_count['SUM(number)'];
		echo $adult_count;
		echo "<br />";
}
echo "Total children attending: ";
while($new_count_ch = $count_child->fetchColumn()){
		$child_count = $new_count_ch['SUM(numberCH)'];
		echo $child_count;
		echo "<br />";
}	
						
echo "Total count: ";
echo $adult_count + $child_count;

?>	
