<?php 
/*
	Author:  Drew D. Lenhart
	http://www.snowytech.com
	Page: dashpanel/dash.php
	Desc: main view screen.	
	*/
	session_start(); 
	$auth= $_SESSION['auth'];
	if ( $auth != "yes" )
	{
		header("Location: index.php");
		exit();
	}

	include("includes/header.php"); 
	require("includes/connection.php");
?>
<div data-role="page" id="page" class = "mainPage" data-theme="a">
	<div data-role="header" data-theme="a">
		<h1>RSVP Dashpanel</h1>
		<div data-role="navbar" data-iconpos="bottom">
			<ul>
				<li><a href="dash.php" data-role="button" data-inline="true" data-icon="check">Attending</a></li>
				<li><a href="noattend.php" data-role="button" data-inline="true" data-icon="minus">Not Attending</a>	</li>
				<li><a href="complete.php" data-role="button" data-inline="true" data-icon="bars">Print List</a></li>
				<li><a href="settings.php" data-role="button" data-inline="true" data-icon="gear">Settings</a></li>			
</ul>
		</div>
		<a href="about.php" data-rel="" data-icon="bars" data-iconpos="" class="ui-btn-left">About</a>
		<a href="logout.php" data-rel="" data-icon="bars" data-iconpos="" class="ui-btn-right">Log Out</a>
	</div>
   <div data-role="content" style="margin-left:15%; margin-right:15%">

		<center>
				<?php include("guest_count.php"); ?>
				<h1>Guests Attending:</h1></center>

<ol data-role='listview' data-theme="a" data-inset="true">
					<?php
					// Select table with query
					$sth = $conn->query("SELECT * FROM guests WHERE attend='yes'");
					if (!$sth) {
						die("Database query failed: " . mysql_error());
					}
					// Set fetching mode
					$sth->setFetchMode(PDO::FETCH_ASSOC);
					?>		
														
					<?php
					// loop display
					if(!sth){
						echo "<br /><br /><br /><br />There is no data!";
					}else{	
					
						foreach ($sth as $row) : 
							$first = $row['firstname'];
							$last = $row["lastname"];
							$entryID = $row['id'];
							$num = $row["number"];
							echo "<li><a href='full_view.php?ID=$entryID' data-rel='dialog'>$first $last</a></li>";			
						endforeach; 			
	
					}?>
					
</ol>
	  
	  <center><b>**Click on the name if you need to make changes.</b></center>
   </div>

</div>

<?php include("includes/footer.php"); ?>
