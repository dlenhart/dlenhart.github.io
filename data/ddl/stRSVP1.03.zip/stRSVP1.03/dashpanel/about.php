<?php 
/*
	Author:  Drew D. Lenhart
	http://www.snowytech.com
	Page: dashpanel/about.php
	Desc: About page.	
	*/
	session_start(); 
	$auth= $_SESSION['auth'];
	if ( $auth != "yes" )
	{
		header("Location: index.php");
		exit();
	}
include("includes/header.php"); ?>

<!--About View----------------------------------------------------- -->
<div data-role="page" id="about" data-theme="a" data-dismissible="false" data-overlay-theme="a">
	<div data-role="header" data-theme="a">
		<h1>About stRSVP</h1>
			<div data-role="navbar" data-iconpos="bottom">
			<ul>
				<li><a href="dash.php" data-role="button" data-inline="true" data-icon="check">Attending</a></li>
				<li><a href="noattend.php" data-role="button" data-inline="true" data-icon="minus">Not Attending</a>	</li>
				<li><a href="complete.php" data-role="button" data-inline="true" data-icon="bars">Print List</a></li>
				<li><a href="settings.php" data-role="button" data-inline="true" data-icon="gear">Settings</a></li>
			</ul>
		</div>
		<a href="about.php" data-rel="" data-icon="bars" data-iconpos="" class="ui-btn-left">About</a>
		<a href="logout.php" data-rel="" data-icon="bars" data-iconpos="" class="ui-btn-right">Log Out</a>
		</div>
		
		<div data-role="content" style="margin-left:20%; margin-right:20%">
		<br /><br /><center>
		<h3>stRSVP</h3>
		Written by:  Drew D. Lenhart<br /><br />
		Technology used:<br />HTML/CSS/Javascript, PHP & Jquery Mobile<br />
		Version:  <b>1.03 - <a href="change_log_st.txt" target="_blank">Change Log</a></b><br /><br />
		
		Support:<br /> <a href="http://www.snowytech.com" target="_blank"><img src="images/snowylogosmall.png" width="180" height="36"></a>
		</center>
		<br />
	
	<br /><br />
				
	</div>
	
</div>

</body>
</html>
