var successPOP = "dashpanel/success.php";
var slide2 = {transition: "slideup"};

//AJAX to add new entryand validate the Foodname if entry
$(document).ready(function() {
    $("#save").click(function(){
 
        var formData = $("#add_form").serialize();
		var slide = {transition: "slideup"};
		var x = document.getElementById('first');
		var y = document.getElementById('last');
		var xSelect = attend.options[attend.options.selectedIndex].value;
		var invalidPop = "dashpanel/invalid_first.php";
		var invalidPop2 = "dashpanel/invalid_last.php";
		
		var slide = {transition: "slideup"};
		
		if (x.value === "" || x.value === null) {
        $.mobile.changePage(invalidPop, slide);
        return false
		}
		if (y.value === "" || y.value === null){
		$.mobile.changePage(invalidPop2, slide);
        return false		
		}
		else{
		
			$.ajax({
				type: "POST",
				url: "add_success.php",
				cache: false,
				data: formData,
				success: addSuccess
			});
 
			return false;
		}
    });
 
    $("#cancel").click(function(){
        resetADDentryFields();
    });
 
    $("#refresh").click(function(){
        location.reload();
    });
});

//Pop up success window ------------
function addSuccess(){
	$.mobile.changePage(successPOP, slide2);
	resetADDentryFields();
}

//reset Add entry txt fields -------

function resetADDentryFields(){
	$("#first").val("");
	$("#last").val("");
	//$("#instruct").val("");
}
