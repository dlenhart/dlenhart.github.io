<div class="sidebar-module sidebar-module-inset">
    <div class="sidebar-module">
        <h4>Categories</h4>
        	<ul>
			<?php wp_list_categories('orderby=name&title_li='); ?> 
			</ul>
    </div>
<div class="sidebar-module">
    <h4>Archives</h4>
        <ul>
            <?php wp_get_archives( array( 'type' => 'monthly', 'limit' => 12 ) ); ?>
        </ul>
    </div>  
</div>