<div class="footer">
    <div><p class="text-muted centerMe">© 2014 yourname.  Powered by <a href="http://www.wordpress.org">Wordpress</a> using the ddlTheme.</p></div>
</div>
</div><!--End main_container-->
	<?php wp_footer(); ?>
</body>
</html>