<?php
/*
Theme Name: ddlTheme
Theme URI: http://www.drewlenhart.com/downloads/
Description: A Bootstrap theme for a small blog.
Author: Drew D. Lenhart
Author URI: http://www.drewlenhart.com
Version: 1.0
Tags: responsive, white, black, bootstrap, jquery

**index.php - Main blog listing.
*/

get_header(); ?>
    
<!--Start row-->
<div class="row inside_container">
<div class="entry_main col-sm-8">
<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>

    <h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
        <?php the_time('F jS, Y'); ?><br />
        <?php the_excerpt(); ?> 
    <br />
<?php endwhile; else: ?>
	<p><?php _e('Sorry, no posts matched your criteria.'); ?></p>
<?php endif; ?>
    
<div style="text-align:center;">
    <?php posts_nav_link(' &#183; ', 'previous page', 'next page'); ?>
</div>    
    
</div>

<div class="col-sm-3 col-sm-offset-1 blog-sidebar">
    <?php get_sidebar(); ?>
</div>

</div><!--End row-->

<?php get_footer(); ?>