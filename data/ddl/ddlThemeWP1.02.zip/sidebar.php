<div class="sidebar-module sidebar-module-inset">
<div class="sidebar-module">
    <?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar() ) : ?>
    <?php endif; ?>
</div>
</div>