<?php 
/*
Theme Name: ddlTheme
Theme URI: http://www.drewlenhart.com/downloads/
Description: A Bootstrap theme for a small blog.
Author: Drew D. Lenhart
Author URI: http://www.drewlenhart.com
Version: 1.0
Tags: responsive, white, black, bootstrap, jquery

**header.php - Contains html header info, css, bootstrap, and navbar
*/
    //Variables to grab WP title and tag line
	$site_title = get_bloginfo( 'name' );
	$site_description = get_bloginfo( 'description' );
?>
<!DOCTYPE html> 
<html>
<head>
<meta charset="utf-8">
<title><?php echo $site_title; ?> - <?php echo $site_description; ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link href="<?php bloginfo('stylesheet_url');?>" rel="stylesheet">
	
	<?php wp_enqueue_script("jquery"); ?>
	<?php wp_head(); ?>
</head> 
<body>

<div class="main_container">

<h2><?php echo $site_title; ?></h2>
<div class="container-fluid">
    <i><small><?php echo $site_description; ?></small></i></div> 
    <br />
<!--Navigation-->
<nav class="navbar navbar-inverse" style="border-radius:none !important" role="navigation">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="<?php echo site_url(); ?>">Home</a>
    </div>
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">
            <?php wp_list_pages(array('title_li' => '')); ?>
      </ul>
    </div>
  </div>
</nav>