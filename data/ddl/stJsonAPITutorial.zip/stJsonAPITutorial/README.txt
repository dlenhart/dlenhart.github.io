stJsonAPI - Drew D. Lenhart - Feb 2016
drewlenhart.com
======================

Please follow along with the written tutorial:

http://www.drewlenhart.com/getting-started-with-a-json-api-using-slim/
http://www.drewlenhart.com/getting-started-with-a-json-api-using-slim-part-2/
http://www.drewlenhart.com/getting-started-with-a-json-api-using-slim-part-3-charts/

======================

Notes:

**Composer needs run to install the vendor files. i.e. Slim.

included is composer.phar,

run:  php composer.par install

======================

Database:

includes/database.class.php

**Don’t forget to insert your MySQL credentials and database name.

